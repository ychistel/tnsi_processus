#!/usr/bin/env python3

# ------------------------------
#  La cuisine du système
#  - manger un abricot
# ------------------------------------------------------------

import actions

abricots = actions.prendre_un_abricot("pour le manger !")
print("Il reste", abricots)
